const express = require("express");
const app = express();
app.use(express.json());

app.post("/answer", (req, res) => {
  res.json({
    score: 70,
    feedback: "Good attempt, try to elaborate more on your technical skills."
  });
});

app.listen(5001, () => console.log("AI Bot backend running on 5001"));
