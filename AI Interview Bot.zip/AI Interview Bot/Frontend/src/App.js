import React, { useState } from "react";

function App() {
  const [messages, setMessages] = useState([
    { from: "bot", text: "Welcome! Tell me about yourself." }
  ]);

  return (
    <div>
      <h1>AI Interview Bot</h1>
      {messages.map((m, i) => (
        <p key={i}><b>{m.from}:</b> {m.text}</p>
      ))}
    </div>
  );
}

export default App;
